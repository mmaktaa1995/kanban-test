<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Information -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <meta name="robots" content="noindex, nofollow"/>
    <meta name="api-base-url" content="/api/">

    <!-- Title -->
    <title>Kanban</title>
    <!-- Style sheets -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet" type="text/css"/>
</head>
<body>
<!-- Vue App-->
<div id="app" class="" v-cloak>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <flash-message></flash-message>
    <kanban-board v-if="board && boardItem && boardItem.id" :board="boardItem"></kanban-board>
    <add-board></add-board>
    <floating-button @click="exportDB">Export DB</floating-button>
</div>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/mohammadaktaa/Desktop/Sites/bem-test/resources/views/vue.blade.php ENDPATH**/ ?>